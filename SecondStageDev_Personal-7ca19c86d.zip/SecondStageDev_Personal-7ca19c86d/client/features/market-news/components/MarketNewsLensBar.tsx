import {
  FIT_FOCUS_VISIBLE,
  cn,
  fitText,
  fitType,
} from "@/components/shared/uiPrimitives";
import type { MarketNewsLensId, MarketNewsLensOption } from "../types";
import styles from "../styles/marketNews.module.css";

function emptyLensTitle(label: string) {
  return label.toLowerCase().includes("stories")
    ? `No ${label} in this view`
    : `No ${label} stories in this view`;
}

export function MarketNewsLensBar({
  activeLensId,
  options,
  onLensChange,
}: {
  activeLensId: MarketNewsLensId;
  options: readonly MarketNewsLensOption[];
  onLensChange: (lensId: MarketNewsLensId) => void;
}) {
  const activeOption =
    options.find((option) => option.id === activeLensId) ?? options[0];

  return (
    <section className={styles.lensPanel} aria-label="News signals">
      <div className="min-w-0">
        <p className={cn(fitType.eyebrow, fitText.label)}>News filters</p>
        <p className={cn("mt-1", fitType.bodySm, fitText.body)}>
          Narrow this story set by your watchlist or explicit ticker links.
        </p>
      </div>
      <div className={styles.lensGrid} role="list">
        {options.map((option) => {
          const active = option.id === activeLensId;
          const disabled = !active && !option.selectable;
          const title = disabled
            ? emptyLensTitle(option.label)
            : option.description;

          return (
            <button
              key={option.id}
              type="button"
              aria-pressed={active}
              disabled={disabled}
              onClick={() => onLensChange(option.id)}
              className={cn(
                styles.lensButton,
                active ? styles.lensButtonActive : "",
                disabled ? styles.lensButtonDisabled : "",
                FIT_FOCUS_VISIBLE,
              )}
              title={title}
            >
              <span className={styles.lensLabel}>
                {option.label}
                <span className="sr-only">: {option.description}</span>
              </span>
              <span className={styles.lensCount}>{option.count}</span>
            </button>
          );
        })}
      </div>
      {activeOption ? (
        <p className={styles.modeDescription}>{activeOption.description}</p>
      ) : null}
    </section>
  );
}
